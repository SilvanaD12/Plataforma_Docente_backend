/* Evaluación por niveles (HU-051): puntaje, niveles que se desbloquean, cronómetro e insignia. */
(function () {
  'use strict';
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function clock(seconds) { return pad(Math.floor(seconds / 60)) + ':' + pad(seconds % 60); }

  window.addEventListener('load', function () {
    var data = document.getElementById('quiz-data');
    if (!data) return;
    var config = JSON.parse(data.textContent);
    var levels = Array.prototype.slice.call(document.querySelectorAll('.level'));
    var scoreOut = document.getElementById('quiz-score');
    var levelOut = document.getElementById('quiz-level');
    var clockOut = document.getElementById('quiz-clock');
    var status = document.getElementById('quiz-status');
    var result = document.getElementById('quiz-result');
    var started = Date.now();
    var score = 0;
    function elapsed() { return Math.round((Date.now() - started) / 1000); }
    var timer = setInterval(function () { clockOut.textContent = clock(elapsed()); }, 1000);

    function unlock(level) {
      level.classList.remove('level--locked');
      var lock = level.querySelector('.level__lock');
      if (lock) lock.hidden = true;
      var controls = level.querySelectorAll('input, button');
      for (var i = 0; i < controls.length; i++) controls[i].disabled = false;
    }

    function badgeFor(percent) {
      for (var i = 0; i < config.badges.length; i++) if (percent >= config.badges[i][0]) return config.badges[i][1];
      return null;
    }

    function finish() {
      clearInterval(timer);
      var seconds = elapsed();
      clockOut.textContent = clock(seconds);
      var percent = config.total ? (100 * score) / config.total : 0;
      var badge = badgeFor(percent);
      var badgeOut = result.querySelector('.result__badge');
      badgeOut.textContent = badge ? 'Insignia de ' + badge.toLowerCase() : 'Sin insignia esta vez: ¡inténtalo de nuevo!';
      badgeOut.className = 'result__badge badge--' + (badge ? badge.toLowerCase() : 'none');
      result.querySelector('.result__summary').textContent = score + ' de ' + config.total + ' puntos (' +
        Math.round(percent) + ' %) en un tiempo de ' + clock(seconds) + '. ' +
        (percent >= config.passing ? 'Aprobaste la evaluación.' : 'Necesitas ' + config.passing + ' % para aprobar.');
      result.hidden = false;
      status.textContent = '¡Terminaste la evaluación!';
      if (window.scorm5e) { window.scorm5e.time(seconds); window.scorm5e.report(percent); }
    }

    function grade(event) {
      event.preventDefault();
      var form = event.currentTarget;
      var chosen = form.querySelector('input[type="radio"]:checked');
      var out = form.querySelector('.feedback');
      if (!chosen) { out.textContent = 'Elige una alternativa.'; return; }
      var correct = chosen.getAttribute('data-correct') === 'true';
      var points = Number(form.getAttribute('data-points')) || 0;
      // La retroalimentación puede empezar con «Correcto.» o «Incorrecto.»: se quita para no repetirlo.
      var note = (chosen.getAttribute('data-feedback') || '').replace(/^\s*(in)?correcto[.:,]?\s*/i, '');
      if (correct) score += points;
      out.textContent = (correct ? 'Correcto, +' + points + ' puntos. ' : 'Incorrecto, 0 puntos. ') + note;
      out.className = 'feedback ' + (correct ? 'is-correct' : 'is-wrong');
      var controls = form.querySelectorAll('input, button');
      for (var i = 0; i < controls.length; i++) controls[i].disabled = true;
      form.classList.add('is-answered');
      scoreOut.textContent = score;

      var level = form.closest('.level');
      if (level.querySelectorAll('.quiz-item:not(.is-answered)').length) return;
      var next = levels[levels.indexOf(level) + 1];
      if (next) {
        unlock(next);
        levelOut.textContent = levels.indexOf(next) + 1;
        status.textContent = '¡' + next.querySelector('h2').firstChild.textContent.trim() + ' desbloqueado!';
      } else {
        finish();
      }
    }

    var forms = document.querySelectorAll('.quiz-item');
    for (var i = 0; i < forms.length; i++) forms[i].addEventListener('submit', grade);
    document.getElementById('quiz-retry').addEventListener('click', function () { window.location.reload(); });
  });
})();
