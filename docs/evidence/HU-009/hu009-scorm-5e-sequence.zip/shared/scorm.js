/* API de SCORM 1.2: busca el objeto API que expone el LMS en las ventanas superiores. */
(function () {
  'use strict';
  function findApi(win) {
    for (var i = 0; win && i < 10; i++) {
      if (win.API) return win.API;
      if (win.parent === win) break;
      win = win.parent;
    }
    return null;
  }
  var api = findApi(window) || (window.opener ? findApi(window.opener) : null);
  var finished = false;

  function setValue(name, value) { if (api) api.LMSSetValue(name, String(value)); }

  function report(percent) {
    setValue('cmi.core.score.min', 0);
    setValue('cmi.core.score.max', 100);
    setValue('cmi.core.score.raw', Math.round(percent));
    setValue('cmi.core.lesson_status', percent >= 60 ? 'passed' : 'failed');
    if (api) api.LMSCommit('');
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  // cmi.core.session_time (CMITimespan de SCORM 1.2): HH:MM:SS.
  function reportTime(seconds) {
    setValue('cmi.core.session_time', pad(Math.floor(seconds / 3600)) + ':' + pad(Math.floor((seconds % 3600) / 60)) + ':' + pad(seconds % 60));
  }
  // HU-047: actividad para iniciar la clase; se registra el puntaje, pero no se aprueba ni se desaprueba.
  function complete(percent) {
    setValue('cmi.core.score.min', 0);
    setValue('cmi.core.score.max', 100);
    setValue('cmi.core.score.raw', Math.round(percent));
    setValue('cmi.core.lesson_status', 'completed');
    if (api) api.LMSCommit('');
  }
  window.scorm5e = { report: report, complete: complete, time: reportTime };

  function speak(button) {
    var target = document.getElementById(button.getAttribute('data-speak'));
    if (!target || !window.speechSynthesis) { button.textContent = 'Este navegador no puede leer el guion en voz alta.'; return; }
    window.speechSynthesis.cancel();
    var utterance = new SpeechSynthesisUtterance(target.textContent);
    utterance.lang = 'es-ES';
    window.speechSynthesis.speak(utterance);
  }

  function start() {
    if (!api) return; // fuera del LMS (vista previa local) la página funciona igual
    api.LMSInitialize('');
    var status = api.LMSGetValue('cmi.core.lesson_status');
    if (document.body.getAttribute('data-kind') === 'content') setValue('cmi.core.lesson_status', 'completed');
    else if (!status || status === 'not attempted') setValue('cmi.core.lesson_status', 'incomplete');
    api.LMSCommit('');
  }

  function finish() {
    if (!api || finished) return;
    finished = true;
    api.LMSCommit('');
    api.LMSFinish('');
  }

  function grade(event) {
    event.preventDefault();
    var form = event.currentTarget;
    var chosen = form.querySelector('input[name="answer"]:checked');
    var out = form.querySelector('.feedback');
    if (!chosen) { out.textContent = 'Elige una alternativa.'; return; }
    var correct = chosen.getAttribute('data-correct') === 'true';
    // La retroalimentación puede empezar con «Correcto.» o «Incorrecto.»: se quita para no repetirlo.
    var note = (chosen.getAttribute('data-feedback') || '').replace(/^\s*(in)?correcto[.:,]?\s*/i, '');
    out.textContent = (correct ? 'Correcto. ' : 'Incorrecto. ') + note;
    out.className = 'feedback ' + (correct ? 'is-correct' : 'is-wrong');
    setValue('cmi.core.score.min', 0);
    setValue('cmi.core.score.max', 100);
    setValue('cmi.core.score.raw', correct ? 100 : 0);
    setValue('cmi.core.lesson_status', correct ? 'passed' : 'failed');
    if (api) api.LMSCommit('');
  }

  window.addEventListener('load', function () {
    start();
    var form = document.getElementById('question');
    if (form) form.addEventListener('submit', grade);
    var buttons = document.querySelectorAll('[data-speak]');
    for (var i = 0; i < buttons.length; i++) buttons[i].addEventListener('click', function (e) { speak(e.currentTarget); });
  });
  window.addEventListener('pagehide', finish);
  window.addEventListener('beforeunload', finish);
})();
