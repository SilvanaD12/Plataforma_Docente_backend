/* Actividades interactivas: emparejar, verdadero o falso, completar, ordenar, exploración guiada,
   actividad kinestésica, reto de predicción y caso aplicado.
   Envían el puntaje con scorm5e. */
(function () {
  'use strict';
  function el(tag, attrs, text) {
    var node = document.createElement(tag);
    for (var key in attrs) node.setAttribute(key, attrs[key]);
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function shuffle(list) {
    var copy = list.slice();
    for (var i = copy.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = copy[i]; copy[i] = copy[j]; copy[j] = t; }
    return copy;
  }
  function norm(text) {
    return String(text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9ñ ]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function mark(row, ok, note) {
    row.className = 'row ' + (ok ? 'row--ok' : 'row--bad');
    var out = row.querySelector('.note') || row.appendChild(el('span', { 'class': 'note' }));
    out.textContent = (ok ? 'Correcto. ' : 'Revisa: ') + (note || '');
  }

  var builders = {
    emparejamiento: function (s, box) {
      var definitions = shuffle(s.pairs.map(function (p) { return p.definition; }));
      return s.pairs.map(function (pair, i) {
        var row = el('div', { 'class': 'row' });
        var id = 'm' + i;
        row.appendChild(el('label', { 'for': id }, pair.term));
        var select = el('select', { id: id });
        select.appendChild(el('option', { value: '' }, 'Elige la descripción…'));
        definitions.forEach(function (d) { select.appendChild(el('option', { value: d }, d)); });
        row.appendChild(select);
        box.appendChild(row);
        return function () { var ok = select.value === pair.definition; mark(row, ok, ok ? '' : pair.definition); return ok; };
      });
    },
    verdadero_falso: function (s, box) {
      return s.statements.map(function (st, i) {
        var row = el('fieldset', { 'class': 'row' });
        row.appendChild(el('legend', {}, st.text));
        ['Verdadero', 'Falso'].forEach(function (label, k) {
          var wrap = el('label', { 'class': 'choice' });
          wrap.appendChild(el('input', { type: 'radio', name: 't' + i, value: k === 0 ? 'true' : 'false' }));
          wrap.appendChild(el('span', {}, label));
          row.appendChild(wrap);
        });
        box.appendChild(row);
        return function () {
          var chosen = row.querySelector('input:checked');
          var ok = !!chosen && (chosen.value === 'true') === st.isTrue;
          mark(row, ok, st.feedback || (st.isTrue ? 'Es verdadera.' : 'Es falsa.'));
          return ok;
        };
      });
    },
    completar_espacios: function (s, box) {
      return s.blanks.map(function (b, i) {
        var row = el('div', { 'class': 'row' });
        var id = 'c' + i;
        row.appendChild(el('label', { 'for': id }, b.sentence));
        var input = el('input', { type: 'text', id: id, autocomplete: 'off' });
        row.appendChild(input);
        box.appendChild(row);
        return function () { var ok = norm(input.value) === norm(b.answer); mark(row, ok, ok ? '' : 'La respuesta es «' + b.answer + '».'); return ok; };
      });
    },
    exploracion_guiada: function (s, box) {
      // HU-048: no hay respuesta correcta; el paso cuenta cuando el estudiante registra lo que encontró.
      return s.guidedSteps.map(function (step, i) {
        var row = el('fieldset', { 'class': 'row step' });
        row.appendChild(el('legend', {}, 'Paso ' + (i + 1) + '. ' + step.title));
        row.appendChild(el('p', {}, step.instruction));
        if (step.source) row.appendChild(el('p', { 'class': 'source' }, 'Fuente: ' + step.source));
        var id = 'g' + i;
        row.appendChild(el('label', { 'for': id }, step.question));
        var answer = el('textarea', { id: id, rows: '3' });
        row.appendChild(answer);
        box.appendChild(row);
        return function () {
          var ok = answer.value.trim().split(/\s+/).length >= 3;
          row.className = 'row step ' + (ok ? 'row--ok' : 'row--bad');
          var out = row.querySelector('.note') || row.appendChild(el('span', { 'class': 'note' }));
          out.textContent = ok ? 'Registro guardado.' : 'Escribe al menos una idea con tus palabras.';
          return ok;
        };
      });
    },
    actividad_kinestesica: function (s, box) {
      // T059 (REV-01): actividad con el cuerpo en el aula. Cada paso con su consigna, la pregunta si la tiene, la
      // fuente, la casilla «Lo hicimos» y un campo opcional para anotar lo observado. El paso cuenta al marcarlo.
      return s.guidedSteps.map(function (step, i) {
        var row = el('fieldset', { 'class': 'row step' });
        row.appendChild(el('legend', {}, 'Paso ' + (i + 1) + '. ' + step.title));
        row.appendChild(el('p', {}, step.instruction));
        if (step.question) row.appendChild(el('p', { 'class': 'question' }, step.question));
        if (step.source) row.appendChild(el('p', { 'class': 'source' }, 'Fuente: ' + step.source));
        var doneLabel = el('label', { 'class': 'choice' });
        var done = el('input', { type: 'checkbox', id: 'k' + i });
        doneLabel.appendChild(done);
        doneLabel.appendChild(el('span', {}, 'Lo hicimos'));
        row.appendChild(doneLabel);
        var id = 'ko' + i;
        row.appendChild(el('label', { 'for': id }, '¿Qué observaron? (opcional)'));
        row.appendChild(el('textarea', { id: id, rows: '2' }));
        box.appendChild(row);
        return function () {
          var ok = done.checked;
          row.className = 'row step ' + (ok ? 'row--ok' : 'row--bad');
          var out = row.querySelector('.note') || row.appendChild(el('span', { 'class': 'note' }));
          out.textContent = ok ? 'Paso hecho.' : 'Marquen «Lo hicimos» cuando terminen este paso.';
          return ok;
        };
      });
    },
    reto_prediccion: function (s, box, activity) {
      // HU-047: el estudiante predice; al elegir ve al instante lo que dice el material y suma puntos y racha.
      var POINTS = 100, STREAK_BONUS = 50;
      var form = box.parentNode;
      var submit = form.querySelector('button[type=submit]');
      if (submit) submit.hidden = true;
      var hud = el('div', { 'class': 'hud', role: 'status', 'aria-live': 'polite' });
      var scoreOut = el('strong', {}, '0');
      var streakOut = el('strong', {}, '0');
      var pointsP = el('p', {}, 'Puntos: '); pointsP.appendChild(scoreOut);
      var streakP = el('p', {}, 'Racha: '); streakP.appendChild(streakOut);
      hud.appendChild(pointsP); hud.appendChild(streakP);
      box.parentNode.insertBefore(hud, box);
      var score = 0, streak = 0, answered = 0, hits = 0;
      var total = s.predictions.length;
      var maxScore = POINTS * total + STREAK_BONUS * Math.max(0, total - 1);
      function finish() {
        var percent = total ? (100 * hits) / total : 0;
        var badge = null;
        (activity.badges || []).forEach(function (b) { if (!badge && percent >= b.min) badge = b.name; });
        var out = form.querySelector('.feedback');
        out.className = 'feedback result';
        out.textContent = '';
        out.appendChild(el('strong', {}, hits + ' de ' + total + ' predicciones acertadas · ' + score + ' de ' + maxScore + ' puntos. '));
        out.appendChild(el('span', { 'class': 'result__badge' }, badge ? 'Insignia: ' + badge + '. ' : ''));
        out.appendChild(el('span', {}, 'No se trata de acertar: compara tus predicciones con lo que verás en la clase.'));
        if (window.scorm5e && window.scorm5e.complete) window.scorm5e.complete(percent);
      }
      return s.predictions.map(function (pr, i) {
        var row = el('fieldset', { 'class': 'row prediction' });
        row.appendChild(el('legend', {}, (i + 1) + '. ' + pr.question));
        var options = shuffle([pr.correctOption, pr.otherOption, pr.extraOption].filter(function (o) { return o; }));
        var buttons = options.map(function (option) {
          var button = el('button', { type: 'button', 'class': 'option' }, option);
          row.appendChild(button);
          return button;
        });
        var reveal = el('p', { 'class': 'reveal', hidden: 'hidden' });
        row.appendChild(reveal);
        box.appendChild(row);
        var hit = false, done = false;
        buttons.forEach(function (button) {
          button.addEventListener('click', function () {
            if (done) return;
            done = true;
            hit = button.textContent === pr.correctOption;
            buttons.forEach(function (b) {
              b.disabled = true;
              if (b.textContent === pr.correctOption) b.className = 'option option--right';
            });
            if (!hit) button.className = 'option option--wrong';
            if (hit) { streak += 1; hits += 1; score += POINTS + (streak > 1 ? STREAK_BONUS : 0); } else { streak = 0; }
            scoreOut.textContent = String(score);
            streakOut.textContent = String(streak);
            reveal.hidden = false;
            reveal.textContent = (hit ? '¡Acertaste! +' + (POINTS + (streak > 1 ? STREAK_BONUS : 0)) + '. ' : 'Era «' + pr.correctOption + '». ') + pr.reveal;
            if (pr.source) reveal.appendChild(el('span', { 'class': 'source' }, ' Fuente: ' + pr.source));
            row.className = 'row prediction ' + (hit ? 'row--ok' : 'row--bad');
            answered += 1;
            if (answered === total) finish();
          });
        });
        return function () { return hit; };
      });
    },
    caso_aplicado: function (s, box) {
      // HU-050: el estudiante escribe su solución y la revisa con los criterios de logro; la califica el docente.
      var card = el('section', { 'class': 'case' });
      card.appendChild(el('p', {}, s.scenario));
      var task = el('p', {});
      task.appendChild(el('strong', {}, 'Consigna: '));
      task.appendChild(document.createTextNode(s.task));
      card.appendChild(task);
      card.appendChild(el('label', { 'for': 'case-solution' }, 'Tu solución'));
      var solution = el('textarea', { id: 'case-solution', rows: '8' });
      card.appendChild(solution);
      var note = el('span', { 'class': 'note' });
      card.appendChild(note);
      box.parentNode.insertBefore(card, box);
      box.appendChild(el('p', {}, 'Criterios de logro: marca los que cumple tu solución.'));
      function written() { return solution.value.trim().split(/\s+/).length >= 15; }
      return s.criteria.map(function (c, i) {
        var row = el('div', { 'class': 'row criterion' });
        var id = 'c' + i;
        var label = el('label', { 'for': id });
        var check = el('input', { type: 'checkbox', id: id });
        label.appendChild(check);
        label.appendChild(el('span', {}, c.criterion));
        row.appendChild(label);
        if (c.source) row.appendChild(el('span', { 'class': 'source' }, 'Fuente: ' + c.source));
        box.appendChild(row);
        return function () {
          var ok = written() && check.checked;
          note.textContent = written() ? '' : 'Escribe tu solución antes de revisarla con los criterios.';
          row.className = 'row criterion ' + (ok ? 'row--ok' : 'row--bad');
          return ok;
        };
      });
    },
    ordenar_pasos: function (s, box) {
      var list = el('ol', { 'class': 'activity__order' });
      shuffle(s.sequence).forEach(function (step) {
        var li = el('li', { 'class': 'row order' });
        li.appendChild(el('span', {}, step));
        var up = el('button', { type: 'button', 'aria-label': 'Subir' }, '↑');
        var down = el('button', { type: 'button', 'aria-label': 'Bajar' }, '↓');
        up.addEventListener('click', function () { if (li.previousSibling) list.insertBefore(li, li.previousSibling); });
        down.addEventListener('click', function () { if (li.nextSibling) list.insertBefore(li.nextSibling, li); });
        li.appendChild(up); li.appendChild(down);
        list.appendChild(li);
      });
      box.appendChild(list);
      return [function () {
        var items = list.querySelectorAll('li');
        var ok = true;
        for (var i = 0; i < items.length; i++) {
          var right = items[i].querySelector('span').textContent === s.sequence[i];
          items[i].className = 'row order ' + (right ? 'row--ok' : 'row--bad');
          ok = ok && right;
        }
        return ok;
      }];
    }
  };

  window.addEventListener('load', function () {
    var form = document.getElementById('activity');
    var data = document.getElementById('activity-data');
    if (!form || !data) return;
    var activity = JSON.parse(data.textContent);
    var build = builders[activity.type];
    if (!build) return;
    var checks = build(activity.structure, form.querySelector('.activity__items'), activity);
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var right = checks.filter(function (check) { return check(); }).length;
      var percent = checks.length ? (100 * right) / checks.length : 0;
      var out = form.querySelector('.feedback');
      var selfAssessed = activity.type === 'caso_aplicado';
      if (activity.type === 'actividad_kinestesica') {
        // T059 (REV-01): se completa cuando todos los pasos están marcados; mientras tanto queda «incompleta».
        out.textContent = right + ' de ' + checks.length + ' pasos hechos.';
        out.className = 'feedback ' + (right === checks.length ? 'is-correct' : 'is-wrong');
        if (right === checks.length && window.scorm5e && window.scorm5e.complete) window.scorm5e.complete(100);
        return;
      }
      out.textContent = activity.type === 'exploracion_guiada'
        ? right + ' de ' + checks.length + ' pasos registrados.'
        : selfAssessed
          ? right + ' de ' + checks.length + ' criterios de logro según tu revisión. Tu docente valorará la solución.'
          : right + ' de ' + checks.length + ' correctas (' + Math.round(percent) + ' %).';
      out.className = 'feedback ' + (percent >= 60 ? 'is-correct' : 'is-wrong');
      // HU-050: el caso aplicado se registra como completado; no se aprueba ni se desaprueba con la autoevaluación.
      if (selfAssessed && window.scorm5e && window.scorm5e.complete) window.scorm5e.complete(percent);
      else if (window.scorm5e) window.scorm5e.report(percent);
    });
  });
})();
